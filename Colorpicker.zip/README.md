# \<color-picker>

A weekend ramp up project demonstrating velocity and how I experiment with something new.

I hope we can discuss and maybe you can help me polish this (WCAG, best practices, etc.)

## Installation

```bash
npm i color-picker
```

## Usage

```html
<script type="module">
  import 'color-picker/color-picker.js';
</script>

<color-picker value=`any-color-string`></color-picker>
```

## Events
Fires a 'color-picked' event with a color object in the event detail 

## Local Demo with `web-dev-server`

```bash
npm start
```

To run a local development server that serves the basic demo located in `demo/index.html`
