import { ColorPicker } from './Colorpicker/ColorPicker.js';

window.customElements.define('color-picker', ColorPicker);
